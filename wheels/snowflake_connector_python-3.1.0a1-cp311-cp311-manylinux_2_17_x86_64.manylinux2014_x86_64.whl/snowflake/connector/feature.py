#!/usr/bin/env python
#
# Copyright (c) 2012-2021 Snowflake Computing Inc. All rights reserved.
#
# Feature flags

feature_use_pyopenssl = True  # use pyopenssl API or openssl command
