#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Copyright (c) 2012-2021 Snowflake Computing Inc. All right reserved.
#

# Feature flags

feature_use_pyopenssl = True  # use pyopenssl API or openssl command
